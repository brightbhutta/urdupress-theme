<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package UrduPress
 */

?>


<div class="home-content">
    <?php the_content(); ?>
</div><!-- .entry-content -->


