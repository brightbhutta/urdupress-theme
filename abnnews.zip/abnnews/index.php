<?php
/**
 * The main template file.
 *
 * @package UrduPress
 */
get_header(); 
?>

	<div id="primary" class="content-area">
		<div class="row ml-0 mr-0 mb-20">
		    <h2 class="text-center">Please Watch Below Video Guide and Setup Your Website Homepage</h2>
		</div>
		<div class="row ml-0 mr-0">
		
            <div class="col-lg-2"></div>
            <div class="video-guide col-lg-12">
                <style>.embed-container { position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; } .embed-container iframe, .embed-container object, .embed-container embed { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }</style><div class='embed-container'><iframe src='https://www.youtube.com/embed/2LmJUZtYr4w' frameborder='0' allowfullscreen></iframe></div>
            </div>
            <div class="col-lg-2"></div>

        </div>
	</div><!-- #primary -->

<?php get_footer(); ?>
