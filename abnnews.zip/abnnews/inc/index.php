<?php
//No kidding