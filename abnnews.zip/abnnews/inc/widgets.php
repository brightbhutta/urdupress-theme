<?php
/*
* Custom Widgets for UrduPress Theme
*/

require get_template_directory() . '/inc/widgets/widget-catposts.php';
require get_template_directory() . '/inc/widgets/widget-featured-pots.php';
require get_template_directory() . '/inc/widgets/widget-slider.php';
require get_template_directory() . '/inc/widgets/widget-classic-block.php';
require get_template_directory() . '/inc/widgets/widget-modern-block.php';
require get_template_directory() . '/inc/widgets/widget-modern-block-v2.php';
require get_template_directory() . '/inc/widgets/widget-grid-block.php';
require get_template_directory() . '/inc/widgets/widget-grid-large.php';
require get_template_directory() . '/inc/widgets/widget-column-block.php';
require get_template_directory() . '/inc/widgets/widget-column-compact.php';