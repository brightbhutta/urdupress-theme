
function stylo_btn_position_select(){
    var currentval = jQuery("#btnPosition").val();
    if(currentval == 3) {
        jQuery(".stylo-short-code-notice").show();
    } else {
        jQuery(".stylo-short-code-notice").hide();
    }

}