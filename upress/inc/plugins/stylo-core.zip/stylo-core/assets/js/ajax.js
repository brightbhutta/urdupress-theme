function stylo_activate_license() {
    //alert("clicjed");
	console.log("clciked");
		jQuery.ajax({
			url : ajaxurl,
			type : 'post',
			data : {
				action : 'stylothemes_activate',
			},
			success : function( response ) {
				jQuery("#wpacAjaxResponse").fadeIn();
				jQuery("#wpacAjaxResponse span").html(response);
				setTimeout(function() {
					location.reload();
				}, 2000);
			}
		});
	
}

function stylo_deactivate_license() {
    //alert("clicjed");
	console.log("clciked");
		jQuery.ajax({
			url : ajaxurl,
			type : 'post',
			data : {
				action : 'stylothemes_deactivate',
			},
			success : function( response ) {
				jQuery("#wpacAjaxResponse").fadeIn();
				jQuery("#wpacAjaxResponse span").html(response);
				setTimeout(function() {
					location.reload();
				}, 2000);
			}
		});
	
}