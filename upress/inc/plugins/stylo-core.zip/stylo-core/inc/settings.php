<?php
function stylo_settings_page_html() {
    //Check if current user have admin access.
    if(!is_admin()) {
        return;
    }
        echo '<div class="wrap">';
            echo '<h1 class="stylo-plugin-settings-head">'.esc_html(get_admin_page_title()).'</h1>';
            echo '<form action="options.php" method="post" class="stylo-setting-form">';
                // output security fields for the registered setting "stylo-settings"
                settings_fields( 'stylo-settings' );

                // output setting sections and their fields
                // (sections are registered for "stylo-settings", each field is registered to a specific section)
                do_settings_sections( 'stylo-settings' );

                // output save settings button
                submit_button( 'Save Changes' );
            echo '</form>';
        echo '</div>';

}

//Top Level Administration Menu
function stylo_register_menu_page() {
    add_menu_page(
        'STYLO THEMES SETTINGS',
        'StyloThemes',
        'manage_options',
        'stylo-settings',
        'stylo_settings_page_html',
        'dashicons-admin-generic', 0 );
}
add_action('admin_menu', 'stylo_register_menu_page');

//Sub-Level Administration Menu
/* function stylo_register_menu_page() {
    add_theme_page( 'WPAC Like System', 'WPAC Settings', 'manage_options', 'stylo-settings', 'stylo_settings_page_html', 30 );
}
add_action('admin_menu', 'stylo_register_menu_page'); */

// Register settings, sections & fields.
function stylo_plugin_settings(){

    // register settings for "stylo-settings" page
    register_setting( 'stylo-settings', 'stylo_license_key' ,['default' => '']);


    // register a new section in the "stylo-setings" page
    add_settings_section(
        'stylo_license_section',
        'Product Activation',
        'stylo_license_section_cb',
        'stylo-settings'
    );

    // register fields for settings in "stylo-settings" page

    // Form Fields
    add_settings_field(
        'stylo_license_key_field',
        'License Key',
        'stylo_license_key_field_cb',
        'stylo-settings',
        'stylo_license_section'
    );
    
}
add_action('admin_init', 'stylo_plugin_settings');

// Section callback functions
function stylo_license_section_cb(){
    _e('<p>Enter Your License Information</p>', 'stylocore');
}

// Field callback functions
// Button Label Fields Callback Functions
function stylo_license_key_field_cb(){ 
    // get the value of the setting we've registered with register_setting()
    $setting = get_option('stylo_license_key');
    $license_key = get_option('stylo_license_key', '');
    $key_options = get_option(STYLOTHEMES_LICENSE_OPTION);
    if(isset($key_options) && $key_options != "") {
        $key_options_json = json_decode($key_options);
        $key_status = $key_options_json->data->status;
    } else {
        $key_status = "";
    }
    $license_validation = stylothemes_is_valid_license($license_key);
    if($license_validation == true && $license_key != '') {
     echo '<input type="text" name="stylo_license_key" value="**************" placeholder="Enter your license key" disabled>';
    } else { 
        if(isset( $setting )) {
            echo '<input type="text" name="stylo_license_key" value="'.$setting.'" placeholder="Enter your license key">';
        } else {
            echo '<input type="text" name="stylo_license_key" value="" placeholder="Enter your license key">'; 
        }
        
    } 
    if($license_key != '') { 
        echo '<div class="license_action_btns">';
        if($key_status != "" && $key_status == "active") {
            echo '<a href="javascript:" onclick="stylo_deactivate_license()" id="deactiavtionBTN" class="button">Deactivate License</a>';
        } else {
            echo '<a href="javascript:" onclick="stylo_activate_license()" id="actiavtionBTN" class="button">Activate License</a>';
        }
        echo '</div>';
        echo '<div id="wpacAjaxResponse"><span></span></div>';
    }
    else { 
        echo '<div class="invalid-license-message">Invalid License Key</div>';
    } 
}
