<?php
/*
* License key Functions 
*/
require_once plugin_dir_path( __FILE__ ). 'LicenseRequest.php';
require_once plugin_dir_path( __FILE__ ). 'Client.php';
require_once plugin_dir_path( __FILE__ ). 'Api.php';

use LicenseKeys\Utility\Api;
use LicenseKeys\Utility\Client;
use LicenseKeys\Utility\LicenseRequest;

define( 'STYLOTHEMES_LICENSE_OPTION', '_stylothemes_license' );

// Activate product
function stylothemes_activate_license( $license_key ) {
    $response = Api::activate(
        Client::instance(), // Client instance
        function() use( $license_key ) {
            return LicenseRequest::create(
                'https://stylothemes.com/shop/wp-admin/admin-ajax.php', // API's base url
                'BqL99oxFQ49RFwf', // API's store code
                'UPRESS', // Related product SKU
                $license_key ,
                LicenseRequest::DAILY_FREQUENCY
            );
        },
        function( $license ) {
           // Here we save the license string into wordpress
           update_option( STYLOTHEMES_LICENSE_OPTION, $license, true );
        }
    );
    return $response;
}
// Validate product
function stylothemes_is_valid_license($license_key) {
    $response = Api::validate(
        Client::instance(), // Client instance
        function() {
            return new LicenseRequest( get_option( STYLOTHEMES_LICENSE_OPTION ) );
        },
        function( $license ) {
           // We update license string
           update_option( STYLOTHEMES_LICENSE_OPTION, $license );
        }
    );
    return $response;
}

// Deactivate product
function stylothemes_deactivate_license() {
    $response = Api::deactivate(
        Client::instance(), // Client instance
        function() {
            return new LicenseRequest( get_option( STYLOTHEMES_LICENSE_OPTION ) );
        },
        function( $license ) {
           // We clear license string
           if ($license === null)
               update_option( STYLOTHEMES_LICENSE_OPTION, null );
        }
    );
    return $response;
}
