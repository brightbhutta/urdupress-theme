<?php

if( !function_exists('stylo_plugin_scripts')) {

    function stylo_plugin_scripts() {

        //Plugin Frontend CSS
        wp_enqueue_style('stylo-css', STYLO_PLUGIN_DIR. 'assets/css/front-end.css');

    }
    add_action('wp_enqueue_scripts', 'stylo_plugin_scripts');

    function stylo_plugin_admin_scripts(){

        //Plugin Back-end CSS
        wp_enqueue_style('stylo-css', STYLO_PLUGIN_DIR. 'assets/css/main.css');
        //Plugin Ajax JS
        wp_enqueue_script('stylo-ajax', STYLO_PLUGIN_DIR. 'assets/js/ajax.js', 'jQuery', '1.0.0', true );
        //Plugin Back-end JS
        wp_enqueue_script('stylo-js', STYLO_PLUGIN_DIR. 'assets/js/main.js', 'jQuery', '1.0.0', true );

    }
    add_action( 'admin_enqueue_scripts', 'stylo_plugin_admin_scripts' );
}