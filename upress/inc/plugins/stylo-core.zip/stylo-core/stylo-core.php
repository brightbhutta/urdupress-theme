<?php
/*
* Plugin Name: Stylo Core
* Plugin URI: https://stylothemes.com
* Author: StyloThemes
* Author URI: https://stylothemes.com
* Description: StyloThems Core Plugin for Theme Settinhs.
* Version: 1.0.0
* License: GPL2
* License URI:  https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain: stylocore
*/

//If this file is called directly, abort.
if (!defined( 'WPINC' )) {
    die;
}

//Define Constants
if ( !defined('STYLO_PLUGIN_VERSION')) {
    define('STYLO_PLUGIN_VERSION', '1.0.0');
}
if ( !defined('STYLO_PLUGIN_DIR')) {
    define('STYLO_PLUGIN_DIR', plugin_dir_url( __FILE__ ));
}

//Create Custom Table For Storing Views Count Data
function create_stylo_views_table(){
	global $wpdb;
	$table_name = $wpdb->prefix . "stylo_views";
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
	  id mediumint(9) NOT NULL AUTO_INCREMENT,
	  user_ip varchar(100) NOT NULL,
	  post_id varchar(255) NOT NULL,
	  country varchar(10) NOT NULL,
	  views_value varchar(255) DEFAULT '0' NOT NULL,
	  time timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	  UNIQUE KEY id (id)
	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}
register_activation_hook( __FILE__, 'create_stylo_views_table' );

// Function to get the client ip address
function get_client_ip_server() {
    $ip_address = '';
    //whether ip is from share internet
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip_address = $_SERVER['HTTP_CLIENT_IP'];
    }
    //whether ip is from proxy
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    //whether ip is from remote address
    else {
        $ip_address = $_SERVER['REMOTE_ADDR'];
    }
 
    return $ip_address;
}
//Get User Country By IP 
function ip_visitor_country($ip_address,$type)
{

    $client = $ip_address;
    $output = $type;
    $country  = "Unknown";

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=".$ip);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $ip_data_in = curl_exec($ch); // string
    curl_close($ch);

    $ip_data = json_decode($ip_data_in,true);
    $ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/

    if($ip_data && $ip_data['geoplugin_countryName'] != null) {
    	if($output == 'name') {
    		$country = $ip_data['geoplugin_countryName'];
    	}
    	elseif($output == 'code') {
    		$country = $ip_data['geoplugin_countryCode'];
    	}
    	elseif($output == 'city') {
    		$country = $ip_data['geoplugin_city'];
    	}
    	else {
    		$country = $ip_data['geoplugin_countryName'];
    	}
        
    }

    return $country;
}

//License Validation
require plugin_dir_path( __FILE__ ). 'inc/license.php';

//Include Scripts & Styles
require plugin_dir_path( __FILE__ ). 'inc/scripts.php';

//Settings Menu & Page
require plugin_dir_path( __FILE__ ). 'inc/settings.php';

//Database Functions
require plugin_dir_path( __FILE__ ). 'inc/db-functions.php';

function stylo_is_plugin_active(){
    return true;
}

//Product Activation
function stylothemes_activate() {
    $license_key = get_option('stylo_license_key', '');
    //$license_key = "jsgdjwgd";
    if($license_key){
        $activate = stylothemes_activate_license($license_key);
        if($activate) {
            $status = $activate->status;
            $message = $activate->message;
            if($status == 500) {
                $message = "Invalid License Key";
            } else {
                $message = $activate->message;
            }
            echo $message;
        }

    }
    
    wp_die();
}
add_action('wp_ajax_stylothemes_activate', 'stylothemes_activate');
add_action('wp_ajax_nopriv_stylothemes_activate', 'stylothemes_activate');

//Product DeActivation
function stylothemes_deactivate() {
    $license_key = get_option('stylo_license_key', '');
    //$license_key = "jsgdjwgd";
    if($license_key){

        $decativate = stylothemes_deactivate_license($license_key);
        if($decativate){
            $status = $decativate->status;
            $message = $decativate->message;
            echo $message;
        }
    }
    
    wp_die();
}
add_action('wp_ajax_stylothemes_deactivate', 'stylothemes_deactivate');
add_action('wp_ajax_nopriv_stylothemes_deactivate', 'stylothemes_deactivate');

function stylo_is_license_key(){
    $license_key = get_option('stylo_license_key', '');
    $key_options = get_option(STYLOTHEMES_LICENSE_OPTION);
    if(isset($key_options) && $key_options != "") {
        $key_options_json = json_decode($key_options);
        $key_status = $key_options_json->data->status;
    } else {
        $key_status = "";
    }
    if($key_status != "" && $key_status == "active") {
        return true;
    } else {
        return false;
    }
}

?>
